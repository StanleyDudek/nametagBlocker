load("nametagBlocker")
registerCoreModule("nametagBlocker")